<?php

return array(  
    'partner' => array(
        'mapABC' => array(
            'appKey' => '817e3f70ed37113574dba086ec488638'
        ),
    	'oss' => array(
            'bucket' => 'nanxiang',
            'domain' => 'http://nanxiang.oss-cn-shanghai.aliyuncs.com',
            'id' => 'sY9wdeajgb0ltkmq',
            'key' => 'fuSeC7pHCFxSEODskG8YCDXWvxEqdT',
            'host' => 'http://oss.aliyuncs.com'
        ),
        'submail' => array(
            'url' => 'http://api.submail.cn/message/xsend.json',
            'appid' => '10418',
            'signature' => '1fa78b2448cac45ba9a345cc0b4c5c68',
            'sign_type' => 'normal',
            'notify_project' => '74nlA3',  //制作完成，通知取货
            'notifyok_project' => 'aURrD',  //已经接单，正在制作
        ),
    	
    )
);