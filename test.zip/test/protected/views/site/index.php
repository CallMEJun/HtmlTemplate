<!-- <h3 style="text-align:center;margin:30px">南翔公司管理平台</h3>
<div class='row-fluid'>
    <div class='span12 box box-transparent'>
        <div class='row-fluid'>
            <div class='span2 box-quick-link blue-background'>
                <a href='/order/list'>
                    <div class='header'>
                        <div class='icon-tasks'></div>
                    </div>
                    <div class='content'>订单管理</div>
                </a>
            </div>
            <div class='span2 box-quick-link green-background'>
                <a href='/good/list'>
                    <div class='header'>
                        <div class='icon-bookmark'></div>
                    </div>
                    <div class='content'>商品管理</div>
                </a>
            </div>
        </div>
    </div>
</div> -->