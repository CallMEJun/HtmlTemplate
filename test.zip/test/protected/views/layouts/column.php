<?php $this->beginContent('//layouts/layout'); ?>
<div class='container-fluid'>
	<div class='row-fluid' id='content-wrapper'>
		<div class='span12'>
			<?php echo $content; ?>
		</div>
	</div>
</div>
<?php $this->endContent(); ?>