<?php $this->beginContent('//layouts/main-mini'); ?>
   
<?php echo $content; ?>

<?php $this->endContent(); ?>