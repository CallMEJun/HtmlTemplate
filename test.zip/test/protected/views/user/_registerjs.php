$(function(){
	$('.btn-register').click(function(){
		alert('ok');
	});
})